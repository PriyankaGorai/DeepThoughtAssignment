using System;
using Microsoft.VisualStudio.TestPlatform.ObjectModel;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using WebDriverManager.DriverConfigs.Impl;
using OpenQA.Selenium.Edge;

namespace DeepThought
{
 
    public class Tests 
    {
        private IWebDriver driver;
        private WebDriverWait wait;

        [SetUp]
        public void Setup()
        {
            string selectedBrowser = Environment.GetEnvironmentVariable("SELECTED_BROWSER");

            // Default to Chrome if no browser is specified
            if (string.IsNullOrEmpty(selectedBrowser))
            {
                selectedBrowser = "Edge";
            }

            // Create the WebDriver based on the selected browser
            switch (selectedBrowser)
            {
                case "Chrome":
                    driver = new ChromeDriver();
                    break;
                case "Firefox":
                    driver = new FirefoxDriver();
                    break;
                case "Edge":
                    driver = new EdgeDriver();
                    break;
                // Add cases for other supported browsers (e.g., Edge, Safari) as needed
                default:
                    throw new ArgumentException("Invalid browser specified");
            }

            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
            driver.Manage().Window.Maximize();

            // Navigate to the Deep Thought website login page
            driver.Navigate().GoToUrl("https://dev.deepthought.education/login");

        }

        [Test]
        public void TestSuccessfulLoginWithValidCredentials()
        {
            // Locate and fill in the login form with valid credentials
            IWebElement usernameInput = driver.FindElement(By.Name("username"));
            IWebElement passwordInput = driver.FindElement(By.Name("password"));
            IWebElement rememberme = driver.FindElement(By.Name("remember"));
            IWebElement loginButton = driver.FindElement(By.XPath(".//button[@id='login']"));

            usernameInput.SendKeys("Priyanka Gorai");
            passwordInput.SendKeys("Priyanka@2000");
            rememberme.Click();
            loginButton.Click();

            // Wait for successful login 
            wait.Until(ExpectedConditions.TitleContains("Dashboard"));

            // Assert that the user is on the dashboard screen
            Assert.IsTrue(driver.Title.Contains("Dashboard"));
        }
        [Test]
        public void TestUnsuccessfulLoginWithInvalidCredentials()
        {
           

            // Locate and fill in the login form with invalid credentials
            IWebElement usernameInput = driver.FindElement(By.Name("username"));
            IWebElement passwordInput = driver.FindElement(By.Name("password"));
            IWebElement rememberme = driver.FindElement(By.Name("remember"));
            IWebElement loginButton = driver.FindElement(By.XPath(".//button[@id='login']"));

            usernameInput.SendKeys("@Priyanka-Gorai6");
            passwordInput.SendKeys("hgga@734");
            rememberme.Click();
            loginButton.Click();

            // Wait for error message (adjust this as needed)
            wait.Until(ExpectedConditions.ElementExists(By.XPath("//div[@id='login-error-notify']")));

            // Assert that an appropriate error message is displayed
            IWebElement errorMessage = driver.FindElement(By.XPath("//div[@id='login-error-notify']"));
            Assert.AreEqual("Login Unsuccessful\r\nInvalid login credentials", errorMessage.Text);
        }

        [Test]
        public void TestSuccessfulLoginRedirectToDashboard()
        {
            // Navigate to the Deep Thought website login page
            

            // Locate and fill in the login form with valid credentials
            IWebElement usernameInput = driver.FindElement(By.Name("username"));
            IWebElement passwordInput = driver.FindElement(By.Name("password"));
            IWebElement rememberme = driver.FindElement(By.Name("remember"));
            IWebElement loginButton = driver.FindElement(By.XPath(".//button[@id='login']"));

            usernameInput.SendKeys("Priyanka Gorai");
            passwordInput.SendKeys("Priyanka@2000");
            rememberme.Click();
            loginButton.Click();

            // Wait for successful login (adjust this as needed)
            wait.Until(ExpectedConditions.TitleContains("Dashboard"));

            // Assert that the user is on the dashboard screen
            Assert.IsTrue(driver.Title.Contains("Dashboard"));
        }
         [TearDown]
         public void Cleanup()
         {
             driver.Quit();
         }
    }
}